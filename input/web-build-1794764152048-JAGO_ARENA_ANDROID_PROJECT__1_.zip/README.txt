JAGO ARENA Android WebView Wrapper (project source)
This is an Android Studio project source, not a precompiled APK.
Open this folder in Android Studio and build: Build > Build APK(s).
The HTML game is bundled in app/src/main/assets/index.html.
